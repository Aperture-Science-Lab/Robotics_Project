#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
import numpy as np


DH_PARAMS = None
T_L7_HAND = None

def plan_trajectory(q_start, q_end, T, dt):
    pass


def compute_dynamics(q, dq, ddq):
    """
    q:   numpy array of 7 joint angles (rad).
    dq:  numpy array of 7 joint velocities (rad/s).
    ddq: numpy array of 7 joint accelerations (rad/s^2).
    
    Returns:
        M_matrix: 7x7 numpy array (Mass/Inertia matrix).
        C_g_vector: 7x1 numpy array (Coriolis + Gravity forces).
    """
    M_matrix = np.zeros((7, 7))
    C_g_vector = np.zeros(7)
    
    return M_matrix, C_g_vector


def fuzzy_controller(error, delta_error, dt):
    """
    error:       7x1 numpy array (desired_q - current_q).
    delta_error: 7x1 numpy array (desired_dq - current_dq).
    dt:          Time step in seconds.
    
    Returns:
        tau_correction: 7x1 numpy array of correction torques.
    """
    tau_correction = np.zeros(7)
    
    return tau_correction


def compute_torques(q, dq, q_des, dq_des, ddq_des):
    """
    q:       current joint positions (7x1).
    dq:      current joint velocities (7x1).
    q_des:   desired joint positions (7x1).
    dq_des:  desired joint velocities (7x1).
    ddq_des: desired joint accelerations (7x1).
    
    Returns:
        final_torques: 7x1 numpy array to send to the motors.
    """
    M, Cg = compute_dynamics(q, dq, ddq_des)
    tau_model = np.dot(M, ddq_des) + Cg
    
    # 2. Calculate the error for the FLC
    error = q_des - q
    delta_error = dq_des - dq  # (Can also be (error - prev_error) / dt)
    
    # 3. Get the correction torque from your FLC
    tau_correction = fuzzy_controller(error, delta_error, 0.01) # 0.01 is dt
    
    # 4. Combine them (You may need to tune how they are added)
    final_torques = tau_model + tau_correction
    
    return final_torques


# ==========================================================
# DO NOT MODIFY BELOW
# ==========================================================

CMD_SIZE = 9
GRIPPER_CTRL = 255.0
TRAJ_DURATION = 4.0
TRAJ_DT = 0.01

# Team-specific start and end configurations.
Q_START = np.zeros(7)
Q_END   = np.zeros(7)

class ControllerNode(Node):
    def __init__(self):
        super().__init__('controller_node')
        self.q_current = np.zeros(7)
        self.dq_current = np.zeros(7)
        
        self.q_traj = None
        self.dq_traj = None
        self.ddq_traj = None
        self.step_idx = 0

        self.create_subscription(JointState, 'joint_state', self.on_joint_state, 10)
        self.cmd_pub = self.create_publisher(Float64MultiArray, 'joint_commands', 10)

        self.create_timer(0.5, self.start_trajectory_once)

    def on_joint_state(self, msg):
        self.q_current = np.array(msg.position[:7])
        if hasattr(msg, 'velocity') and len(msg.velocity) >= 7:
            self.dq_current = np.array(msg.velocity[:7])

    def start_trajectory_once(self):
        if self.q_traj is not None:
            return

        result = plan_trajectory(Q_START, Q_END, TRAJ_DURATION, TRAJ_DT)
        if result is None:
            return

        _, self.q_traj, self.dq_traj, self.ddq_traj = result
        self.get_logger().info("Trajectory generated. Starting Controller.")
        
        # Switch to the control loop timer
        self.destroy_timer(self.timers[0])
        self.create_timer(TRAJ_DT, self.control_loop)

    def control_loop(self):
        if self.step_idx >= len(self.q_traj):
            # Hold final position by sending zero velocity and holding torque
            cmd = Float64MultiArray()
            M, Cg = compute_dynamics(self.q_current, np.zeros(7), np.zeros(7))
            cmd.data = Cg.tolist() + [GRIPPER_CTRL, 0.0]
            self.cmd_pub.publish(cmd)
            return

        q_des = self.q_traj[self.step_idx]
        dq_des = self.dq_traj[self.step_idx]
        ddq_des = self.ddq_traj[self.step_idx]

        torques = compute_torques(
            self.q_current, self.dq_current, 
            q_des, dq_des, ddq_des
        )

        cmd = Float64MultiArray()
        cmd.data = torques.tolist() + [GRIPPER_CTRL, 0.0]
        self.cmd_pub.publish(cmd)

        self.step_idx += 1


def main(args=None):
    rclpy.init(args=args)
    node = ControllerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()